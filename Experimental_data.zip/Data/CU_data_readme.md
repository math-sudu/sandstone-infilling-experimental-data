# CU material-characterization data

Manuscript: CONBUILDMAT-D-26-18332.

The files cover KG1–KG6, whose gypsum:kaolin mass ratios are respectively
0, 0.25, 0.5, 1, 2 and 4. KG1 uses the medium-density kaolin condition.
The CU experiments were conducted within the research group and documented
in Wang Rongxin's master's thesis, *Research on Propagation Characteristics
of Fracture Grouting in Clay Formation*, Beijing Jiaotong University (2020,
in Chinese), Section 2.4, Tables 2-9 and 2-10, as cited in manuscript Section 2.3.
The English title follows the original thesis title page.

Chinese bibliographic identification: 王荣鑫. 黏土地层劈裂注浆扩散特性研究.
硕士学位论文, 北京交通大学, 2020.

DOI: [10.26944/d.cnki.gbfju.2020.003107](https://doi.org/10.26944/d.cnki.gbfju.2020.003107).
The DOI Handle record directs readers to CNKI and the Chinese DOI service.

The rock-filling and CU preparations used dry calcined kaolin and the same
total-water/dry-kaolin mass ratio of 0.23. Any starting-powder moisture was accounted for in the
added water. Water divided by total dry solids is consequently
`0.23 / (1 + r)`, where `r` is the dry gypsum:kaolin mass ratio.

## Test design and source coverage

The thesis specifies three parallel tests per density–pressure combination
in Section 2.4.1 (printed p. 27); Section 2.4.2 uses the same procedure for
the gypsum mixtures. For KG1–KG6, six conditions × three pressures × three
parallel cylinders gives 54 tests. Tables 2-9 and 2-10 explicitly report
three parallel parameter results per condition, with their means listed
separately (printed pp. 30 and 33).

For these six conditions, Figs. 2-17 and 2-21–2-25 display eighteen
experimental curves, one at each pressure per condition. The attachments
cover all these displayed curves and all eighteen parallel parameter
triplets in the selected table rows.

## CU_stress_strain_data.csv

The file contains 272 coordinates of experimental stress–strain curves covering six conditions
at total cell pressures of 100, 200 and 300 kPa, with 18 condition–pressure
combinations in total.

Curve coordinates were extracted from the experimental plots in the thesis.
A curve ID such as `KG3-S2-P200-D` identifies condition
KG3, the source's parameter-series column 2 and 200 kPa confinement;
the suffix `D` distinguishes curve-coordinate records from parameter estimates.

The paired panels in each source figure provide the mapping: panel (a)
shows the three pressure curves, and panel (b) labels the fitted envelope
with c and phi. Both labels match one of the three columns in the source
parameter table. The following links use the labels in the printed
figures and tables.

| Condition | Source figure | Printed page (PDF page) | Parameter series | Envelope c (kPa) | Envelope phi (degrees) |
|---|---|---|---:|---:|---:|
| KG1 | 2-17(a,b) | 29 (40) | 1 | 23.09 | 15.66 |
| KG2 | 2-21(a,b) | 32 (43) | 1 | 152.94 | 26.42 |
| KG3 | 2-22(a,b) | 32 (43) | 2 | 200.58 | 29.76 |
| KG4 | 2-23(a,b) | 32 (43) | 2 | 229.90 | 32.12 |
| KG5 | 2-24(a,b) | 33 (44) | 3 | 273.16 | 32.46 |
| KG6 | 2-25(a,b) | 33 (44) | 1 | 310.35 | 33.15 |

Each linked series has three displayed pressure curves. The source tables
supply eighteen parameter triplets. In manuscript Fig. 3(i), the displayed
200-kPa curves use the series listed above, while the legend c values (26, 160, 215, 229, 285 and
329 kPa) are rounded condition means across all three parameter estimates.
Panel (j) likewise uses condition-mean c and phi.
Parameter statistics use the three tabulated estimates per condition.

| Column | Meaning |
|---|---|
| curve_id | Experimental-curve identifier, with the original source-series link |
| condition | KG1–KG6 |
| parallel_series | Column 1–3 in the source parameter table, linked through its companion envelope panel |
| gypsum_to_kaolin_mass_ratio | Gypsum mass divided by kaolin mass |
| confining_pressure_kPa | Total cell pressure, kPa |
| point_index | Point order along each curve |
| axial_strain_percent | Axial strain, percent |
| deviator_stress_kPa | Total axial stress minus confining pressure, kPa |

## CU_parallel_parameters.csv

The file lists eighteen parameter triplets from the three parallel-result
columns in Wang (2020), Table 2-9, medium-density row (printed p. 30;
PDF p. 41), and Table 2-10 (printed p. 33; PDF p. 44). The source describes
three parallel tests at each pressure; each c/phi envelope spans 100,
200 and 300 kPa. For each of c, phi and E0, the condition mean is the
arithmetic average of the three tabulated parallel estimates; the sample
standard deviation is calculated from those same three values. The source
tables list columns 1–3 and the resulting mean separately. For example,
the KG2 cohesion values 152.94, 148.54 and 179.74 kPa average to
160.41 kPa, and its initial moduli 31.28, 32.51 and 29.64 MPa average
to 31.14 MPa.

For each test, the failure deviator stress `qf` is the peak value for a
curve with a distinct peak, or the value at 15% axial strain for a
continuously hardening curve. The corresponding total major principal
stress is `sigma1f = sigma3 + qf`. Within each parallel series, the three
confining-pressure results are fitted by `sigma1f = A * sigma3 + B`.
With compression positive, the Mohr–Coulomb parameters are
`phi = asin((A - 1) / (A + 1))` and `c = B / (2 * sqrt(A))`.
The CSV reports phi in degrees and c in kPa. Each parallel series yields
one pair of c and phi.

E0 denotes the source's tabulated initial modulus Ei. The parallel-series
index identifies its column in the source table.
The supplied parameters characterize the bulk mixtures. The elastic
band sensitivity settings are specified in manuscript Section 2.5.

| Column | Meaning |
|---|---|
| condition | KG1–KG6 |
| gypsum_to_kaolin_mass_ratio | Gypsum mass divided by kaolin mass |
| parallel_series | Parallel CU parameter-set index, 1–3 |
| c_kPa | Total-stress CU cohesion, kPa |
| phi_degrees | Total-stress CU friction angle, degrees |
| E0_MPa | Initial modulus, MPa |
| confining_pressures_kPa | Total cell pressures for the series, kPa |

## Source records and data processing

`CU_provenance_manifest.csv` gives one row for each of the eighteen
display curves and eighteen parameter triplets, including the original
figure/table, row, printed/PDF page and basis for the series link.
`CU_source_extract.pdf` contains nine unaltered source pages: the original
thesis title page followed by printed pp. 26–33, preserving their page numbers.
The title page identifies the author, supervisor, university, Chinese and
English titles, and June 2020 date. The manifest's PDF page numbers refer to
the complete 132-page thesis, not to this nine-page extract.

The source describes the TSZ/Tgwin apparatus, layered compaction,
three confining pressures and the peak/15%-strain failure rule. The
authors confirm that the reported 100, 200 and 300 kPa are total cell
pressures. Specimens were saturated by incrementally increasing
back pressure, with a pore-pressure coefficient B of at least 0.95 used
to check saturation. After saturation, the drainage lines were opened
for isotropic consolidation at the prescribed effective consolidation
stress, equal to the total cell pressure minus the applied back pressure.
Drainage volume was monitored with time; consolidation was
complete when the drainage rate fell below 0.1 mL/h. The drainage lines
were then closed for undrained shearing at constant total cell pressure.
The shear-strength parameters use total stresses. The source-page and series mappings above document the extraction; means
and sample SDs can be recalculated directly from `CU_parallel_parameters.csv`.
