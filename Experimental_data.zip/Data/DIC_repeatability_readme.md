# DIC measurements, repeatability and sensitivity data

CONBUILDMAT-D-26-18332. All values labeled `_um` are in micrometres.
These data accompany the DIC methods and spatial analysis.

The manuscript's nested-gauge results are in
`R1-08_nested_supported_stages.csv`, `R1-08_nested_supported_specimens.csv`
and `R1-08_nested_supported_summary.csv`, also collected in the workbook's
`Nested_results` sheet. They use the image-supported patches and retain
all 48 peak transects in each reference-frame comparison. Files named
`R1-08_nested_frame_*` contain the earlier untrimmed-patch comparison;
they are not the source of the manuscript's final nested-gauge values.

Source-project and field identifiers retain their specimen folder and original
filename; local drive prefixes are omitted from the delivery CSVs. The analysis
commands below refer to the research project. Reprocessing the raw DIC fields
requires the original camera images and VIC projects, available from the
corresponding author on request.

The current near-end results use the fixed image-cleared supports in
`dic_supported/` and the files prefixed `R2-11_support_`. The earlier
`dic_revised/` and unprefixed repeatability files retain the untrimmed
patch results for comparison. `R2-10_peak_correction_comparison.csv`
isolates the curved-surface selection correction at the original gauge
positions. Final near-end values additionally use the full-subset
image-clearance selection described below. The current FE comparison uses the same
image-supported near-end gauges and is supplied in FE_reproduction.zip.

## Gauge geometry and paired measurements

### Reference-coordinate eligibility

Seventeen rock specimens have stereo images and correlated fields; KG1-2's
images were not saved when the acquisition disk filled. Their reference
geometry is evaluated independently of the subsequent support selection:

- `R2-10_metric_geometry.csv` contains the annotated slot length, image
  length, reference grid pitch and reference-coordinate drift.
- `R2-10_calibration_check.csv` triangulates every 25th finite,
  correlation-valid reference stereo match. For each match it reports the
  larger of the two camera reprojection residuals. A rigid fit compares
  the reconstructed points with the stored XYZ fields, accounting for the
  saved specimen coordinate frame. The archived target calibration supplies
  a separate diagnostic comparison.
- `R2-10_local_geometry.csv` applies that same reprojection calculation
  to every finite reference point in each near-end candidate face and in
  a 100-by-100-pixel neighborhood of each annotated physical end. Candidate
  faces use 8 < |s| < 14 mm and 1.5 < |n| < 5 mm, the union of the
  10/11/12-mm station windows. Image-end neighborhoods follow the original
  pixel annotations independently of the metric scale. The script
  `R2-10_local_geometry.py` uses reference X/Y/Z coordinates, stereo
  matches and correlation status.

KG2-1 reconstructs the nominal 30-mm slot as 53.074 mm, with 788.708 pixels
between the annotated ends. The other sixteen projects give 25.818–31.875 mm
for 711.424–835.545 pixels. Its projected grid pitch is 0.4683 mm per
7-pixel step, versus 0.2515–0.2658 mm elsewhere. The reference fields are
constant through loading; the distorted metric scale is present before
the displacement comparisons.

With its own saved calibration, KG2-1 has full-surface median/P95
reprojection residuals of 1.030/4.720 pixels. Other projects' P95 values
are 0.082–0.248 pixels. Its local P95 residuals are:

| Region | P1 (pixels) | P5 (pixels) | Other sixteen projects (pixels) |
|---|---:|---:|---:|
| Candidate face A | 0.408 | 1.214 | 0.028–0.252 |
| Candidate face B | 1.019 | 1.421 | 0.020–0.419 |
| Annotated image end | 4.454 | 0.771 | 0.044–0.612 |

The joint physical-scale and stereo inconsistency prevents locating
prescribed millimetre gauges in KG2-1. This is a reference-reconstruction
failure affecting both ends and all stages. The saved XYZ coordinates agree
with triangulation using the saved project calibration to less than
0.00001 mm in all projects.
The original target calibration changes KG2-1's centered XYZ scale by a
factor of 0.562 and gives coordinates different from the saved reconstruction.

KG2-1 is consequently excluded from metric displacement and strain
comparisons. Its images remain available for qualitative inspection.
The finite untrimmed values in `R2-10_geometry_filter_sensitivity.csv`
are diagnostic calculations in the same distorted coordinate system.
Final footprint support is marked `not_evaluated_metric_failure` for
this specimen in `R2-10_dic_availability.csv`, separately from image/field
availability. All sixteen eligible specimens retain both ends at all
five stages. Eligibility is evaluated from the known slot geometry and
reference stereo matches.

### Image-cleared physical supports

`R2-11_gauge_support.py` maps each reference subset square locally to
flaw-normal coordinates and both peak camera images. Affine-fit residual
maxima enlarge the footprint envelopes. Subsets must clear the nominal
slot envelope, |n| <= 1.55 mm, and manually traced visible rock cracks in
both cameras. The camera-0 traces in `R2-11_crack_traces.json` are transferred
through local stereo correspondences to camera 1 and checked on its image.
The primary crack corridor is 7 pixels (one grid step); 0 and 14 pixels
are sensitivity checks. This corridor defines the geometric crack-clearance
boundary.

Candidate centers are at signed distances 10, 11 and 12 mm from the flaw
center, with |s-s_i| < 2 mm and 1.5 < |n| < 5 mm. At each end, the selected
center maximizes the smaller retained face count under the 14-pixel
corridor; ties favor 12 mm. Thirty ends use 10 mm, while KG6-1 P1 and
KG6-2 P5 use 12 mm. Selection uses image coverage and correlation validity,
independently of displacement signs. Each patch average combines
17–128 overlapping subset centers. The same
material points remain valid at all five stages and in all 2329 saved
pre-peak frames across the sixteen histories.

The end margin is abs(CSD)-abs(COD); the specimen margin is the equal-weight
mean of its two end margins. This operation takes absolute values before
averaging. Signed end COD and its two-end mean describe normal motion
continuously. The manuscript reports component medians and margin ranges,
with all sixteen specimens retained. The requested sensitivity comparison
checks margins > 2u for u = 3, 6, 7, 9 and 12 µm; 7 rounds up the larger
observed unloaded in-plane fluctuation. The earlier threshold CSVs retain
normal-motion classes as comparison outputs.

The support comparisons retain the original untrimmed mask, the nominal-slot
half-diagonal clearance, actual pixel-square slot clearance, three crack
corridors at the selected centers, and three uniform candidate centers.
Missing values for a uniform candidate mean that one face at that position
has no remaining full subset; the selected-support panel has both ends in
all specimens. In `R2-11_support_decomposition.csv`, the old-minus-new
face contribution is the sum of common-point reweighting, removed-point
and added-point terms. The signs account for A minus B. The identity holds
even when supports have no common points; a changed support samples a
different part of the measured displacement field.

## Acquisition and calculation

The first 10 s of every acquisition were unloaded, at 10 stereo frames/s.
Fifteen specimens use frames 1–100 with frame 1 as a fixed reference.
KG3-1 uses frames 40–100 (3.9–9.9 s) with its original reference frame 51:
frames 1–34 are nearly dark (maximum pixel intensity at most 7/255), and
frames 35–39 precede the stable illumination from frame 40. This interval
was selected from image brightness, before displacement statistics.
The self-correlated references are omitted, leaving 1545 stereo sets,
16 specimens, 32 tip gauges and 3090 tip observations.

The independent calculation uses affine inverse-compositional Gauss–Newton
correlation, Gaussian-weighted zero-mean normalized squared differences,
and cubic B-spline interpolation. For subset side length S, the Gaussian
standard deviation is (S−1)/4 pixels. Correlation uses the original image
intensities and retains temporal drift. Convergence is a maximum
corner-warp update below 0.0001 pixel; all selected points converged.
Each image is correlated against its fixed reference, with the previous
solution initializing the next solve.

The calculation retains the saved 59–83-pixel subsets, stereo calibration
and material points in the manuscript's two tip gauges. KG4-2's points are
tracked from its archived frame 522 to frame 1 before the static calculation.
Triangulated displacements are rotated into the archived specimen axes.
COD/CSD signs and P1/P5 labels follow the manuscript. CTD_W is the signed
out-of-plane difference between the same two rock-face strips.

The method follows Pan, Li and Tong (2013), *Experimental Mechanics* 53,
1277–1289, https://doi.org/10.1007/s11340-013-9717-6. The independent
interpolation differs from VIC's optimized 8-tap interpolation. The comparison
file reports both calculations at identical gauge points and archived reference
frames: 38 tip observations in 19 image sets across all sixteen specimens.
Maximum absolute COD/CSD differences are 0.163/0.124 µm (RMS 0.069/0.062 µm).
Seventeen sets are within the unloaded interval; the first available deformed
outputs for KG3-1 and KG4-2 are frames 101 and 579, respectively.

## Files and columns

| File | Contents |
|---|---|
| `dic_supported/tip_stages.csv`, `specimen_stages.csv`, `ext_*.csv` | Current image-cleared near-end measurements: 160 end-stage rows, 80 paired specimen-stage rows, and sixteen pre-peak histories with the submitted-baseline frame/force values. |
| `R2-11_crack_traces.json` | Visible peak-image crack polylines in native camera-0 pixels and the corridor definition. |
| `R2-11_support_points.csv` | Candidate material-point indices and coordinates, both image-footprint boxes, map residuals, face membership and the nine support masks. |
| `R2-11_support_stages.csv` | Both-end values for nine supports at five stages, with station coordinates, patch centroids and point counts. |
| `R2-11_support_classification.csv` | Earlier end/specimen C/O/I and joint counts, plus component-margin counts, totals and margins for u = 3, 6, 7, 9 and 12 µm. |
| `R2-11_support_decomposition.csv` | Exact old/new peak face-average decomposition, including removed and added support. |
| `R2-11_support_load_windows.csv` | Initial-loading window increment summaries on the current fixed supports. |
| `R2-11_support_static_series.csv` | Each independently calculated non-reference frame and end: specimen, source folder ID, frame, time, references, subset size, point counts, signed COD/CSD/CTD_W and correlation diagnostics. |
| `R2-11_support_static_summary.csv` | Each specimen/end/component: frame coverage, reference, point counts, mean, temporal sample SD, RMS, 95th percentile, maximum, span and fitted drift slope. |
| `R2-11_support_direct_comparison.csv` | Independent and archived VIC measurements on the current supports, their signed differences, reference-axis residual and correlation diagnostics; rows with frame <= 100 provide the 34 native unloaded observations. |
| `R2-11_static_series.csv`, `R2-11_static_summary.csv`, `R2-11_static_repeats.csv`, `R2-11_direct_comparison.csv` | Preserved corresponding results for the former untrimmed patches. |
| `R2-10_peak_correction_comparison.csv` | Surface-selection-only comparison at all 22 shared submitted peak stations, before final image-clearance selection: signed COD, CSD, nominal sign changes, point counts and earlier normal classifications at 6 µm. |
| `R2-10_dic_availability.csv` | All 36 tips: submitted peak availability, corrected coverage at five load stages, recovery status and reasons for the four unavailable metric records. |
| `R2-10_geometry_filter_sensitivity.csv` | The former flat-Z filter, finite correlation-valid selection and quadratic-surface residual selection at two tips and five stages in all 17 archived projects. The comparison for metric inference uses the 16 retained specimens. |
| `R1-08_nested_frame_transects.csv` | Three transects per specimen in each of three common reference frames: signed inner/outer/rock increments, their ratio, opposing-sign indicator and point counts. |
| `R1-08_nested_frame_summary.csv` | Frame-wise counts and sixteen-specimen summaries after taking the within-specimen median over the three transects. |
| `R3-15_strain_filter_sensitivity.csv` | Native 9/15/21-point Lagrange-strain recalculations for KG1-1, KG4-1 and KG6-2 at 0.75 and 1.00 peak load; amplitude, rank and spatial-overlap comparisons. |
| `R3-15_displayed_filter_sensitivity.csv` | Both strain components at the exact eighteen displayed frames; three filters on fixed whole-field and stereo-footprint-cleared sandstone supports, including comparison with native 15-point values. |
| `R3-15_filter_spatial_profiles.csv` | Fixed 1-mm distance profiles for the same stages, fields and supports; P95 intensity and signed mean/minimum/maximum. |
| `R3-15_filter_support.csv` | Nominal window, center span and subset-inclusive projected support for 9/15/21 points in the sixteen-specimen common panel. |
| `R3-15_subset_clearance.csv` | Peak COD/CSD for the reported gauges and gauges cleared from the nominal slot by the physical subset half-diagonal; point counts are given for both patches. |

`time_s=(frame−1)/10`; `n_A` and `n_B` are the fixed point counts on the
opposing strips. `blur_sigma_pixels=0` records no image preblur.
`znssd_max` and `iterations_max` are the largest pointwise values across
both cameras in the current stereo set; ZNSSD is dimensionless.
`reference_alignment_max_um` is the maximum point residual after rigid
alignment of triangulated reference coordinates to saved specimen axes.

Summary statistics exclude the zero self-correlated reference. Sample SD
uses n−1; RMS is relative to zero, with bias and drift retained. `span_um`
includes the zero reference and therefore bounds every pairwise difference
within that observed interval. `drift_um_per_s` is a descriptive linear
slope within the observed window.

## Interpretation

| Component | Pooled RMS | Maximum absolute difference | Within-gauge SD range |
|---|---:|---:|---:|
| COD | 1.26 | 6.49 | 0.09–1.55 |
| CSD | 1.16 | 6.79 | 0.09–1.78 |
| CTD_W | 3.52 | 18.08 | 0.28–4.73 |

The largest within-gauge spans are also 6.49, 6.79 and 18.08 µm.
The 7 µm in-plane comparison allowance rounds up the observed short-term
COD/CSD fluctuations. These summaries describe temporal repeatability of
the gauge averages over the observed interval, with specimens as the
experimental units. The previous untrimmed patches
gave COD/CSD RMS values of 0.94/0.89 µm and maxima of 4.44/4.57 µm;
these results remain in the corresponding comparison files.

The surface correction removes the former selection within 0.5 mm of the
mean reference Z-coordinate. The archived correlated fields, reference
frames, coordinate projections and patch-averaging formulas are retained.
The former filter reproduces all 22 submitted peak COD values to their
0.001-µm tabulation precision (maximum difference 0.00048 µm). A separate
0.5-mm residual screen against a robust quadratic reference surface retains
the same patch point counts and gives identical COD, CSD and CTD_W values
as finite correlation-valid selection in all 160 metric records. Each patch
contains 161–237 points before the image-footprint selection. The
controlled-filter results reproduce `dic_revised/tip_stages.csv` to
floating-point precision.

The comparison file separates crossings of zero from normal classifications
at 6 µm. Its 12 nominal sign changes comprise ten closure-to-opening changes,
one indeterminate-to-opening change and one closure-to-indeterminate change.
The coverage file identifies 22 `shared` peak stations, ten
`recovered_after_filter_correction` stations and four `unavailable` records.
The latter are KG1-2's two tips (`images_not_saved_disk_full`) and KG2-1's
two tips (`reference_reconstruction_anomaly`). Correlated-history availability
is recorded separately from eligibility for metric inference.

From the project root, reproduce the comparison and coverage tables with:

```powershell
python -B evidence/R2-10_correction_comparison.py
python -B evidence/R2-11_dic_sensitivity.py --availability-only
```

Reproduce the image-supported results and their uncertainty with:

```powershell
python -B evidence/R2-11_gauge_support.py
python -B evidence/R2-11_gauge_support.py --histories
python -B evidence/R2-11_gauge_support.py --loading-windows
python -B evidence/R2-11_direct_dic.py --image-support --pilot
python -B evidence/R2-11_direct_dic.py --image-support
python -B evidence/R2-11_static_noise.py --image-support
```

The surface-correction comparison script also checks known opening and closure at both stations,
joint reversal of the side labels and normal direction, and a consistent
mirror of coordinates and displacement vectors. COD retains its physical
sign in each coordinate convention.

For the nested gauges, `fixed` retains the reference axes. `rigid_all`
and `rigid_far` remove one common three-dimensional rigid motion fitted
to all visible points or points more than 10 mm from the nominal slot,
respectively. The fit is applied separately at the quarter-load and peak
frames. `host_CSD_um=outer_CSD_um-inner_CSD_um`; `host_over_outer` uses the
signed outer increment as denominator. All three frame treatments use the
same point supports. The three transects are nested within a specimen,
so the displacement and ratio summaries give each specimen equal weight.

### Image-supported nested gauges and span contrast

`R1-08_nested_support.py` applies the existing full-subset slot envelope
and two-camera crack exclusions to the central stations s = -6, 0, 6 mm
and the exterior fitting points. The candidate offsets remain
1.5 < |n| < 5 mm (inner) and 10 < |n| < 12 mm (outer); the half-width
along the flaw remains 2 mm. The same 1869 submitted-basis pre-peak frames
and sixteen specimens are retained. The point sets are fixed through each
history. Peak-image overlays were inspected at all sixteen specimens in
both cameras; the image traces define crack clearance for these central
and exterior supports.

For the reported 7-pixel corridor, patches contain 66--135 centers.
Actual normal centroid separations are 8.0415--8.7408 mm (inner) and
21.7902--22.0759 mm (outer), with medians 8.4541 and 22.0007 mm.
The span-normalized contrast is `K = Di/li - Do/lo`, in micrometres/mm.
It is calculated from signed increments before magnitude summaries.
`paired_reduction_um = abs(Di) - abs(Do)` is calculated for each transect.
The median of three transects gives each specimen's value; the sixteen
specimen values then supply the cohort median and interquartile range.

The `R1-08_nested_supported_` CSVs contain:

- `points`: native point indices, reference s/n coordinates, patch membership
  and 0/7/14-pixel clearance masks, including the exterior fit region.
- `stages`: signed inner/outer and both intervening-rock terms, actual spans,
  K, paired changes, ratios, counts and three-dimensional geometry vector eta
  at all five stages, three frames and three corridors (2160 rows).
- `history`: the fixed-frame, 7-pixel measurements through the 1869 frames
  (5607 transect rows), with the actual quarter-load anchor and load fraction.
- `specimens` and `summary`: the two levels of statistical reduction.
- `controls`: prescribed translation, 1-degree three-dimensional rotation
  and symmetric uniform strain on the actual point geometry. For a uniform
  gradient G, the residual K equals `s dot G eta`; affine recovery and rigid
  recovery of a pure rigid field are checked using the actual
  three-dimensional patch centroids.
- `exterior`: current near-end observations and predictions from one affine
  field, separate rigid motions and separate affine fields. The observed
  operators reproduce `dic_supported/tip_stages.csv` after subtracting each
  measured quarter-load value. The near-end points are withheld from fitting.
- `static`: the same nested gauges applied to the retained 17 unloaded VIC
  stereo pairs from fourteen specimens (51 transect observations), with
  bias and drift retained. K RMS is 0.03695 micrometres/mm and its observed
  maximum absolute value is 0.13078 micrometres/mm. This is a gauge-specific
  archive check. The sixteen-specimen independent near-end repeatability
  sequences are described above.

The peak specimen-median |K| values for fixed/whole-surface/distant-rock
frames are 29.66089/29.64675/29.67933 micrometres/mm. All 48 transects have
K in the direction of Di and an opposing intervening-rock contribution in
each frame. The largest individual change relative to the fixed frame is
0.29982%. The 0- and 14-pixel corridor alternatives give fixed-frame cohort
medians 29.72337 and 29.66089; the largest individual change is 2.14526%.
The actual homogeneous exterior affine field contributes at most
0.07185 micrometres/mm through the three-dimensional centroid mismatch.
The prescribed controls verify the geometric formula and affine recovery
to floating-point precision; pure rigid fields are removed to that precision.

In the fixed frame, median |Di|/|Do| are 342.09025/257.59093 micrometres.
The paired reduction has specimen median 86.68469, IQR [76.22536, 95.49333]
and specimen range [50.89659, 123.37032] micrometres. The original untrimmed
48-transect results (46/45/48 opposing across the three frames) remain in
`R1-08_nested_frame_transects.csv` and `R1-08_nested_frame_summary.csv`.
The new calculation independently recovers all those original signed
inner/outer values before reporting the image-supported results. The
original `R1-08_spatial_*` files are likewise retained.

Reproduce the current nested-gauge results:

```powershell
python -B evidence/R1-08_nested_support.py
python -B evidence/R1-08_nested_support.py --static-repeats
```

The manuscript spatial figure is drawn from the image-supported CSVs.

### Displayed strain sequences and full spatial support

`R3-15_strain_filter_sensitivity.py` now defaults to the six sequences in
`figures/fig/fig07_attribution_generated.provenance.json`. The early/late/peak
frames are KG1-1 2042/2993/3573, KG2-2 2074/2982/3522, KG3-1
1955/2858/3199, KG4-1 1752/2653/3019, KG5-1 2025/2907/3270 and
KG6-2 2069/2979/3597. These match the manuscript display table.
The earlier three-specimen q = 0.75/1.00 CSV is preserved; `--legacy`
reproduces it. Its three peak cases agree with the new P95 and Dice.

Native dimensionless Lagrange strains are recomputed in memory from the
same displacements. Each specimen has 13560--15989 common valid points
across three stages and windows. Signed εxy is retained; |εxy| supplies
shear intensity. The recalculated 15-point P95 values and upper-5% sets
equal the archived values for every component/stage/region comparison.
KG3-1 has pointwise differences up to 6.640155e-6 (εxy); the other five
specimens match exactly.

For grid pitch p and subset width S pixels, nominal window = Np,
center span = (N−1)p, and full pixel support = (N−1)×7+S, following
`CorrelatedSolutionsStrainFilter` in the bibliography. Projected full
supports are 4.1319--5.0853, 5.6409--6.6219 and 7.1499--8.1634 mm
for 9/15/21. The older CSV's `filter_window_mm` is Np. These calibrated
projected widths describe the spatial support of the measurements.

The sandstone mask clears the complete 21-point-plus-subset footprint
from the slot in both reference cameras. Camera 0 uses a square of side
(21−1)×7+S. Camera 1 uses actual reference correspondences
(x+q_ref, y+r_ref) of the 21-point grid, expanded by S/2 pixels.
Local affine maps convert both footprints to flaw s/n coordinates;
maximum map residuals enlarge their bounding rectangles (maximum residual
0.3058 mm). Both rectangles must clear |n|≤1.55 mm and
|s|≤max(30.1 mm, annotated length)/2. Strain does not enter selection.
A known affine stereo control recovers the exact footprint exclusion.
Fixed masks retain 6211/6234/7589/7146/7883/7383 points in display order.

Dice = twice the common upper-5% count divided by the two set-size sum.
It and rank correlation describe spatial agreement. Evolution is assessed
by P95 on fixed supports; spatial profiles give every populated 1-mm
distance shell and preserve signed shear statistics.

At peak whole-field P95 changes are −18.1283%/+20.8987% (ε1) and
−19.4124%/+19.6799% (|εxy|); Dice is 0.87906--0.94000 and
0.82045--0.86975. Sandstone-control P95 ranges are −65.6943%/+84.5989%
and −57.9429%/+92.6096%; Dice is 0.79241--0.98158 and
0.76206--0.98947. High-strain median distances from the slot shift by
at most 0.17431/0.27637 mm. Profiles show reduced narrow peaks and
elevated band margins with wider windows; a percentile over slot-excluded
rock can change more than the whole-field percentile.

All six specimens, three filters and both components increase at both
loading transitions on both supports. Sandstone-control late-to-peak
gains are 18.1791--145.5590% and 19.5796--91.3448%. Early weak sandstone
fields have lower minimum Dice (0.58939/0.54662). Across all stages,
sandstone P95 changes reach −67.3065%/+145.6745% and
−62.0208%/+92.6096%. These observations remain in the CSV. The paper's
quantitative spatial comparison uses peak fields; evolution is tested
at all three stages.

```powershell
python -B evidence/R3-15_strain_filter_sensitivity.py
```

The strain-filter method and comparison table are in Sections 2.4.2 and 3.4.
